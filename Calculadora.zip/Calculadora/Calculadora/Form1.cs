namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int valor1 = Convert.ToInt32(textBox1.Text);
            int valor2 = Convert.ToInt32(textBox2.Text);

            int resultado = valor1 + valor2;
            MessageBox.Show(resultado.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int valor1 = Convert.ToInt32(textBox1.Text);
            int valor2 = Convert.ToInt32(textBox2.Text);

            int resultado = valor1 - valor2;
            MessageBox.Show(resultado.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int valor1 = Convert.ToInt32(textBox1.Text);
            int valor2 = Convert.ToInt32(textBox2.Text);

            int resultado = valor1 * valor2;
            MessageBox.Show(resultado.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int valor1 = Convert.ToInt32(textBox1.Text);
            int valor2 = Convert.ToInt32(textBox2.Text);

            int resultado = valor1 / valor2;
            MessageBox.Show(resultado.ToString());
        }
    }
}